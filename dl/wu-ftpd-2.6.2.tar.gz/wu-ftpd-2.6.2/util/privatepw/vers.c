char version[] = "Version wu-2.6.2(1) Fri Aug 4 14:51:49 CEST 2006";
