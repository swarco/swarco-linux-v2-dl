char version[] = "Version wu-2.6.2(2) Fri Aug 4 15:28:15 CEST 2006";
