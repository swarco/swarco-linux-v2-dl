char *vgetty_version = "experimental test release 0.9.32 / with duplex patch";
