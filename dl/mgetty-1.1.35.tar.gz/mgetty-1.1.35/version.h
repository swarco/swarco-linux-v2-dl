char * mgetty_version = "interim release 1.1.35-Feb22";
