char * mgetty_version = "official release 1.0.0";
