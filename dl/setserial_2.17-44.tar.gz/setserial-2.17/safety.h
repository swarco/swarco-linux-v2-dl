
/* The list is searched with PORT_UNKNOWN searched first. Thus it is safe
 * to reuse that again.
 */

#define PORT_SAFETY PORT_UNKNOWN

#ifndef PORT_8250
#define PORT_8250 PORT_SAFETY
#endif

#ifndef PORT_16450
#define PORT_16450 PORT_SAFETY
#endif

#ifndef PORT_16550
#define PORT_16550 PORT_SAFETY
#endif

#ifndef PORT_16550A
#define PORT_16550A PORT_SAFETY
#endif

#ifndef PORT_CIRRUS
#define PORT_CIRRUS PORT_SAFETY
#endif

#ifndef PORT_16650
#define PORT_16650 PORT_SAFETY
#endif

#ifndef PORT_16650V2
#define PORT_16650V2 PORT_SAFETY
#endif

#ifndef PORT_16750
#define PORT_16750 PORT_SAFETY
#endif

#ifndef PORT_16C950
#define PORT_16C950 PORT_SAFETY
#endif

#ifndef PORT_16C950
#define PORT_16C950 PORT_SAFETY
#endif

#ifndef PORT_16C950
#define PORT_16C950 PORT_SAFETY
#endif

#ifndef PORT_16654
#define PORT_16654 PORT_SAFETY
#endif

#ifndef PORT_16850
#define PORT_16850 PORT_SAFETY
#endif

#ifndef ASYNC_LOW_LATENCY
#define ASYNC_LOW_LATENCY 0x2000
#endif
