/*
 * @file          wlogin.c
 * Starts a shell with auto-logout after a given time.
 * @program-call: wlogin <shell_to_execute> <timeout_in_secs>
 * @version       1.0
 * @date          <2006-10-09 15:01:33 mf>
 * @author        Markus Forster
 * Changes:
 *                2006-10-09 mf: initial version
 */   

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pty.h>
#include <termios.h>
#include <pthread.h>
#include <time.h>

#include <sys/ioctl.h>
#include <sys/signal.h>
#include <sys/wait.h>
#include <sys/types.h>

#define MAX_CHARS 4096

static time_t ref_time;  /* reference time, first set
			  * if parent process is started.
			  */

void catch(int sig){
  exit(1);
}

/* checks idle time every second and terminates process if
 * idletime exeeds timeout value 
 */
void *idlecounter(int *timeout){
  time_t act_time;
  while(1){
    fflush(0);
    usleep(1000000);
    act_time = time(&act_time);
    if ((act_time - ref_time) >= *timeout){
      exit(1);
    }
  }
  pthread_exit(NULL);
}

void *wlogin(char *prog){
  int pty_pid = -1;
  int status;
  int master, slave;
  int n, m;
  char mbuf[MAX_CHARS], sbuf[MAX_CHARS];
  fd_set fds, tmp;
  int retval;

  /* Create a new process on a new pty */
  
  openpty(&master, &slave, NULL, NULL, NULL);
  
  FD_ZERO(&fds);
  FD_SET(STDIN_FILENO,&fds); /* stdin */
  FD_SET(master, &fds);

  if ((pty_pid = fork()) < 0){
    perror("error on fork");
    exit(2);
  }
  else if (pty_pid == 0){
    login_tty(slave);
    execl(prog, "-sh", NULL);
    perror("geht net\n");
    exit(33);
  }
  else{
    while((pty_pid = waitpid(-1, &status, WNOHANG)) == 0){
      tmp = fds;
      if ((retval = select(master+1, &tmp, 0, 0, 0)) == -1)
	perror("select()");
      if (retval > 0){
	if (FD_ISSET(master, &tmp)){
	  n = read(master, mbuf, sizeof(mbuf));
	  write(STDOUT_FILENO, mbuf, n);
	  if (n == 0)
	    break;
	}
	if(FD_ISSET(STDIN_FILENO, &tmp)){
	  m = read(STDIN_FILENO,sbuf,sizeof(sbuf));
	  if (m == 0)
	    break;
	  ref_time = time(&ref_time);
	  write(master, sbuf, m);
	}
      }
    }
    exit(0);
  }
  pthread_exit(NULL);  
}

int main(int argc, char *argv[]){
  pthread_t p1; /* thread of process 1 */
  pthread_t p2; /* thread of process 2 */
  
  char prog[MAX_CHARS]; /* program to execute */
  static int timeout = 0; /* timeout interval in secs */

  if( argc != 3){
    printf("\nUsage: wlogin <programm_to_execute> <timeout_intervall>\n\n");
    printf("Report bugs to:\n\n");
    printf("markus.forster@weiss-electronic.de\n\n");
    exit(0);
  }
  
  ref_time = time(&ref_time);

  strcpy(prog, argv[1]);
  timeout = strtol(argv[2],NULL,10);

  signal(SIGPIPE, catch);
  signal(SIGKILL, catch);
  signal(SIGCHLD, catch);
  
  
  pthread_create(&p1, NULL, idlecounter, &timeout);
  pthread_create(&p2, NULL, wlogin, &prog);
  
  pthread_join(p1, NULL);
  pthread_join(p2, NULL);
  
  return 0;
}

/* EOF 
 *   compile command: gcc -D_REENTRANT wlogin.c -o wlogin -lpthread -l util
 */
